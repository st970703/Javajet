package se254.a4.q2;

import java.util.List;

public interface A {
	void m1(int x, int y);

	int m2(Object a);

	Object m3();

	double m4(Object b);
	
	boolean m5();
	
	List m6();
}

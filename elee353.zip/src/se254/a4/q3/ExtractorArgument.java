package se254.a4.q3;

public class ExtractorArgument {
	public String className;
	public Class<?> a;
	public Class<?> b;
}

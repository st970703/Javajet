package se254.a4.q3;

public class A {
	public int x;
	public String y;
	public double z;
}

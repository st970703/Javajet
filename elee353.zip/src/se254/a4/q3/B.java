package se254.a4.q3;

public class B {
	public int a;
	public String y;
	public int z;
}

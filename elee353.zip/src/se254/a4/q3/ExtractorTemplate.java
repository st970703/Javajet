package se254.a4.q3;

import java.lang.reflect.*;
import java.util.*;

public class ExtractorTemplate
{
  protected static String nl;
  public static synchronized ExtractorTemplate create(String lineSeparator)
  {
    nl = lineSeparator;
    ExtractorTemplate result = new ExtractorTemplate();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL;
  protected final String TEXT_3 = NL + "\t";
  protected final String TEXT_4 = NL + "\t\t";
  protected final String TEXT_5 = NL + "\t\t\t";
  protected final String TEXT_6 = NL + "\t\t";
  protected final String TEXT_7 = NL + "\t";
  protected final String TEXT_8 = NL;
  protected final String TEXT_9 = NL + "public class ";
  protected final String TEXT_10 = " {";
  protected final String TEXT_11 = NL + "\t";
  protected final String TEXT_12 = NL + "}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     ExtractorArgument ea = (ExtractorArgument) argument; 
     Class a = (Class) ea.a; 
     Class b = (Class) ea.b; 
    stringBuffer.append(TEXT_1);
     Field[] aField = a.getDeclaredFields(); 
     Field[] bField = b.getDeclaredFields(); 
     ArrayList<Field> tempField = new ArrayList<Field>(); 
    stringBuffer.append(TEXT_2);
     for( Field af : aField ) { 
     
    stringBuffer.append(TEXT_3);
     for( Field bf : bField ) { 
    stringBuffer.append(TEXT_4);
     if (af.getName().equals(bf.getName()) && af.getType().equals(bf.getType()) ) {
    stringBuffer.append(TEXT_5);
     tempField.add(af); 
    stringBuffer.append(TEXT_6);
     } 
    stringBuffer.append(TEXT_7);
     } 
    stringBuffer.append(TEXT_8);
     } 
    stringBuffer.append(TEXT_9);
    stringBuffer.append( ea.className );
    stringBuffer.append(TEXT_10);
     for( Field f : tempField ) { 
    stringBuffer.append(TEXT_11);
    stringBuffer.append( f.toString().split(" ")[0] +" "+ f.getType().getSimpleName()+" "+f.getName()+";\n" );
     } 
    stringBuffer.append(TEXT_12);
    return stringBuffer.toString();
  }
}
